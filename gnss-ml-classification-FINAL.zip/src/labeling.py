
import pandas as pd
from constants import THRESHOLDS, LABEL_MAP

class GNSSLabeler:
    def threshold_label(self, df):
        labels = []
        confidences = []

        for _, row in df.iterrows():
            div = abs(row['code_carrier_div'])
            elev = row['elevation_norm'] * 90.0

            if elev > THRESHOLDS['LOS']['elevation_min'] and div < THRESHOLDS['LOS']['code_carrier_max']:
                labels.append(0)
                conf = 1 - div / THRESHOLDS['LOS']['code_carrier_max']
            elif elev < THRESHOLDS['NLOS']['elevation_max'] and div > THRESHOLDS['NLOS']['code_carrier_min']:
                labels.append(2)
                conf = min(1.0, div / 10)
            else:
                labels.append(1)
                conf = 0.7

            confidences.append(max(min(conf, 1.0), 0.1))

        df['label'] = labels
        df['label_confidence'] = confidences
        df['label_str'] = df['label'].map(LABEL_MAP)
        df['low_confidence'] = df['label_confidence'] < 0.7

        return df
