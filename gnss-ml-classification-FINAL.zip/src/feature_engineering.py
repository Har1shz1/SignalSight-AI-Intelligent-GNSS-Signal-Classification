
import numpy as np
import pandas as pd
from constants import L5_WAVELENGTH

class GNSSFeatureEngineer:
    def __init__(self):
        self.feature_names = []

    def extract_basic_features(self, df, carrier_col, clock_col, pr_col, elevation_col):
        df = df.copy()

        df['carrier_delay_m'] = df[carrier_col] * L5_WAVELENGTH
        df['corrected_carrier'] = df['carrier_delay_m'] - df[clock_col]
        df['code_carrier_div'] = df[pr_col] - df['corrected_carrier']
        df['code_carrier_ratio'] = df[pr_col] / df['corrected_carrier'].replace(0, np.finfo(float).eps)

        df['elevation_rad'] = np.radians(df[elevation_col])
        df['elevation_norm'] = df[elevation_col] / 90.0
        df['elevation_sin'] = np.sin(df['elevation_rad'])
        df['elevation_cos'] = np.cos(df['elevation_rad'])

        df['multipath_indicator'] = df['code_carrier_div'] * df['elevation_sin']

        df['code_carrier_mean'] = df['code_carrier_div'].rolling(5, center=True).mean()
        df['code_carrier_std'] = df['code_carrier_div'].rolling(5, center=True).std()

        df['code_carrier_diff'] = df['code_carrier_div'].diff()
        df['elevation_diff'] = df[elevation_col].diff()

        self.feature_names = [
            col for col in df.columns
            if col not in [carrier_col, clock_col, pr_col, elevation_col]
        ]
        return df

    def extract_advanced_features(self, df):
        df = df.copy()
        df['multipath_delay_metric'] = df['code_carrier_div'] * (1 - df['elevation_sin'])
        return df

    def get_feature_list(self):
        return self.feature_names
