
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

from feature_engineering import GNSSFeatureEngineer
from labeling import GNSSLabeler
from models import GNSSModelFactory
from evaluation import GNSSEvaluator

if __name__ == "__main__":
    df = pd.read_csv("../data/sample.csv")

    fe = GNSSFeatureEngineer()
    df = fe.extract_basic_features(df, "Carrier Delay-4", "Clock Bias", "PR-4", "Elevation-4")
    df = fe.extract_advanced_features(df)

    labeler = GNSSLabeler()
    df = labeler.threshold_label(df)

    X = df[fe.get_feature_list()].fillna(0)
    y = df['label']

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.3, random_state=42, stratify=y
    )

    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)

    evaluator = GNSSEvaluator()

    for name, model in GNSSModelFactory.get_models().items():
        print(f"\n===== {name} =====")
        model.fit(X_train, y_train)
        preds = model.predict(X_test)
        evaluator.evaluate(y_test, preds)
