
"""
Constants for GNSS Signal Processing
Used for L5 frequency band calculations and physical constants
"""

# Physical Constants
SPEED_OF_LIGHT = 299792458.0  # m/s
L5_FREQUENCY = 1.17645e9      # Hz
L5_WAVELENGTH = SPEED_OF_LIGHT / L5_FREQUENCY

# Signal Classification Thresholds
THRESHOLDS = {
    'LOS': {'elevation_min': 45.0, 'code_carrier_max': 2.0},
    'MULTIPATH': {'elevation_min': 15.0, 'elevation_max': 45.0, 'code_carrier_min': 2.0, 'code_carrier_max': 5.0},
    'NLOS': {'elevation_max': 15.0, 'code_carrier_min': 5.0}
}

LABEL_MAP = {0: 'LOS', 1: 'MULTIPATH', 2: 'NLOS'}
